const GET_DATA = 'GET_DATA'
export { GET_DATA }
