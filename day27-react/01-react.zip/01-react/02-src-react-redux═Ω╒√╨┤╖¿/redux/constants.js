const INCREMENT = 'INCREMENT'
const PUSH = 'PUSH'
export { INCREMENT, PUSH }
