import { createStore } from 'redux'
import reducer from './reduer'
export default createStore(reducer)
