import React from 'react'
console.log('home.js加载了')
export default function Home() {
  return <div>首页</div>
}
