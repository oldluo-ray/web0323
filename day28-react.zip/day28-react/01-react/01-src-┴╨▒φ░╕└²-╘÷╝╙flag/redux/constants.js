const GET_DATA = 'GET_DATA'
const SET_FLAG = 'SET_FLAG'
export { GET_DATA, SET_FLAG }
